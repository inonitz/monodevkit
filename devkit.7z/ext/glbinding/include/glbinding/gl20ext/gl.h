
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl20ext/types.h>
#include <glbinding/gl20ext/boolean.h>
#include <glbinding/gl20ext/values.h>
#include <glbinding/gl20ext/bitfield.h>
#include <glbinding/gl20ext/enum.h>
#include <glbinding/gl20ext/functions.h>
