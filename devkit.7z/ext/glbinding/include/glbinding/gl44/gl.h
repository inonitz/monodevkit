
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl44/types.h>
#include <glbinding/gl44/boolean.h>
#include <glbinding/gl44/values.h>
#include <glbinding/gl44/bitfield.h>
#include <glbinding/gl44/enum.h>
#include <glbinding/gl44/functions.h>
