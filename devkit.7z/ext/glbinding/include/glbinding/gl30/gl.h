
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl30/types.h>
#include <glbinding/gl30/boolean.h>
#include <glbinding/gl30/values.h>
#include <glbinding/gl30/bitfield.h>
#include <glbinding/gl30/enum.h>
#include <glbinding/gl30/functions.h>
