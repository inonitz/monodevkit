
#pragma once


#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl32
{


using gl::GL_INVALID_INDEX;

using gl::GL_TIMEOUT_IGNORED;


} // namespace gl32
