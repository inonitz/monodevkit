
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl46core/types.h>
#include <glbinding/gl46core/boolean.h>
#include <glbinding/gl46core/values.h>
#include <glbinding/gl46core/bitfield.h>
#include <glbinding/gl46core/enum.h>
#include <glbinding/gl46core/functions.h>
