
#pragma once


#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl15
{





} // namespace gl15
